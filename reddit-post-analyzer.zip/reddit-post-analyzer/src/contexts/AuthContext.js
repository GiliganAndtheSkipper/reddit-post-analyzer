import React, { createContext, useState, useEffect } from "react";
import axios from "axios";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setLoading(true);
        axios.get('/api/user')
          .then(response => {
            setUser(response.data);
            setError(null);
          })
          .catch(error => {
            console.error('Failed to fetch user:', error);
            setError(error);
            setUser(null);
          })
          .finally(() => setLoading(false));
    }, []);

    return (
        <AuthContext.Provider value={{ user, setUser, error, loading }}>
            {children}
        </AuthContext.Provider>
    );
};