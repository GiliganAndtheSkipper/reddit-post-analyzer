import { useCallback } from 'react';
import axios from 'axios';

const useExportData = () => {
    const getDataForExport = useCallback(async () => {
        try {
            const response = await axios.get('/api/data/for/export');
            return response.data;
        } catch (error) {
            console.error('Failed to fetch data for export:', error);
            return [];
        }
    }, []);

    return {
        getDataForExport
    };
};

export default useExportData;