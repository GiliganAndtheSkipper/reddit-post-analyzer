import axios from 'axios';

export const fetchPosts = (filter = 'all') => async dispatch => {
    dispatch({ type: 'FETCH_POSTS_REQUEST' });

    try {
        let url = `https://www.reddit.com/r/reactjs/new.json`;
        if (filter !== 'all') {
          url += `?t=${filter}`;
        }

        const response = await axios.get(url);
        const posts = response.data.data.children;

        dispatch({
            type: 'FETCH_POSTS_SUCCESS',
            payload: posts
        });
    } catch (error) {
        dispatch({
            type: 'FETCH_POSTS_FAILURE',
            payload: error.message
        });
    }
};