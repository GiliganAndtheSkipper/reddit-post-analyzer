// src/redux/slices/sentimentSlice.js

import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { fetchSentimentAnalysis as fetchSentimentAnalysisAPI } from '../../api/sentimentApi';

export const fetchSentimentAnalysis = createAsyncThunk(
    'sentiment/fetchSentimentAnalysis',
    async (subreddit, { rejectWithValue }) => {
        try {
            const response = await fetchSentimentAnalysisAPI(subreddit);
            return response.data;
        } catch (error) {
            return rejectWithValue(error.response.data);
        }
    }
);

const sentimentSlice = createSlice({
    name: 'sentiment',
    initialState: {
        data: [],
        loading: false,
        error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchSentimentAnalysis.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchSentimentAnalysis.fulfilled, (state, action) => {
                state.loading = false;
                state.data = action.payload;
            })
            .addCase(fetchSentimentAnalysis.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload || "Failed to fetch sentiment data";
            });
    }
});

export default sentimentSlice.reducer;