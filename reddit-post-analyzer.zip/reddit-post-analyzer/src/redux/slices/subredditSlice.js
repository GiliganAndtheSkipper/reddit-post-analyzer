// src/redux/slices/subredditSlice.js

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from 'axios';

export const fetchSubredditData = createAsyncThunk(
    'subreddit/fetchData',
    async (subredditName, { rejectWithValue }) => {
        try {
            const response = await axios.get(`https://www.reddit.com/r/${subredditName}/.json`);
            return response.data.data.children.map(child => child.data);
        } catch (error) {
            return rejectWithValue(error.response.data);
        }
    }
);

const subredditSlice = createSlice({
    name: 'subreddit',
    initialState: {
        posts: [],
        loading: false,
        error: null
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
        .addCase(fetchSubredditData.pending, (state) => {
            state.loading = true;
        })
        .addCase(fetchSubredditData.fulfilled, (state, action) => {
            state.posts = action.payload;
            state.loading = false;
        })
        .addCase(fetchSubredditData.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload ? action.payload.errorMessage : 'Could not load data';
        });
    }
});

export default subredditSlice.reducer;