import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchEngagement = createAsyncThunk('engagement/fetchEngagement', async () => {
    const response = await axios.get('/api/engagement');
    return response.data;
});

const engagementSlice = createSlice({
    name: 'engagement',
    initialState: {
        data: null,
        loading: false,
        error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchEngagement.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchEngagement.fulfilled, (state, action) => {
                state.data = action.payload;
                state.loading = false;
            })
            .addCase(fetchEngagement.rejected, (state, action) => {
                state.error = action.error.message;
                state.loading = false;
            });
    }
});

export default engagementSlice.reducer;