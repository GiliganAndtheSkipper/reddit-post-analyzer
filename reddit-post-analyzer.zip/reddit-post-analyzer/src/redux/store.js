// src/redux/store.js

import { configureStore } from '@reduxjs/toolkit';
import postsReducer from './slices/postsSlice';
import userReducer from './slices/userSlice';
import sentimentReducer from './slices/sentimentSlice';
import engagementReducer from './slices/engagementSlice';

const store = configureStore({
  reducer: {
    posts: postsReducer,
    user: userReducer,
    sentiment: sentimentReducer,
    engagement: engagementReducer,
  },
});

export default store;